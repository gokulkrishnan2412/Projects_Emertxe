#ifndef DECODE_H
#define DECODE_H

#include "encode.h"
#include "common.h"
#include "types.h" // Contains user defined types

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
    /* Source Image info */
    char *src_image_fname;
    FILE *fptr_src_image;
    uint image_capacity;
    uint bits_per_pixel;
    char image_data[MAX_IMAGE_BUF_SIZE];

    /* Secret File Info */
    char *secret_fname;
    FILE *fptr_secret;
    char extn_secret_file[MAX_FILE_SUFFIX];
    char secret_data[MAX_SECRET_BUF_SIZE];
    uint size_secret_file;

    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;

} DecodeInfo;

/* Decoding function prototype */

/* Get File pointers for i/p and o/p files */
Status open_files_decode(EncodeInfo *encInfo);

/* close files for clean exit */
void close_files_decode(EncodeInfo *encInfo);

/* Decode secret file size */
Status decode_secret_file_size(FILE * fptr_stego_image, long *size_secret_file);

/* decode a byte into array from LSB of image data  */
Status decode_byte_fromlsb(char *data, char *image_buffer);

/* Decode secret file data */
Status decode_secret_file_data(FILE * fptr_secret, FILE * fptr_stego_image, long size_secret_file);

#endif
